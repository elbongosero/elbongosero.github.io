# hvo_sequence
A Piano Roll Representation for Drums Similar to Sequence Representations in Magenta's GrooVAE
