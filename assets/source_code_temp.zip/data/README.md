# Preprocessing Data for Training / Testing / Evaluating
## Instructions for preprocessing data into HVO_Sequqnce format to be used in training/evaluation pipelines

----

### Currently supported datasets
##### 1. [Groove Midi Dataset](https://www.tensorflow.org/datasets/catalog/groove): Magenta's groove midi dataset
    
    run data/gmd/preprocess_to_HVO_Sequence.ipynb

##### 2. ... 



